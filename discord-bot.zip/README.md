# Discord Bot on Koyeb (Node.js & Python)

## 概要
- Node.js (TypeScript 使用) と Python 版の両方を含む構成です
- GitHub 経由でリポジトリを Koyeb にデプロイできます

## デプロイ手順
1. リポジトリを GitHub に Push
2. Koyeb アカウントで応用アプリを作成
3. GitHub と連携し、対象リポジトリとブランチを指定
4. 環境変数 `DISCORD_BOT_TOKEN` を Secret としてセット
5. Procfile に従ってアプリ起動（例：Node.js 版）
6. 自動デプロイ・24時間稼働が可能です

## コマンド
- `!ping` → `Pong! 🏓`
