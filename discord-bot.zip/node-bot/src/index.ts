import { Client, GatewayIntentBits } from "discord.js";
import server from "./server";

const client = new Client({
  intents: [GatewayIntentBits.Guilds, GatewayIntentBits.GuildMessages, GatewayIntentBits.MessageContent],
});

client.once("ready", () => {
  console.log(`Logged in as ${client.user?.tag}`);
});

client.on("messageCreate", (message) => {
  if (message.content === "!ping") {
    message.reply("Pong! 🏓");
  }
});

server.listen(3000, () => {
  console.log("Health-check server listening on port 3000");
});

client.login(process.env.DISCORD_BOT_TOKEN);
